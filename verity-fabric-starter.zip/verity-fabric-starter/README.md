# Verity Fabric — independent starter

Target: Minecraft Java 1.20.1, Fabric Loader, Java 17.

This is a clean Fabric Loom starter, not a port of the original Verity JE and not yet a playable mod. It deliberately contains no source code or assets copied from the original project. The intended work is an independent implementation of horror gameplay systems, with original code and assets or assets used with permission.

## Build without a PC

The GitHub Actions workflow builds the project in GitHub's cloud when you upload/push this folder to a repository. Open the Actions tab and download the `verity-fabric-build` artifact from a successful run. The output JAR will be under `build/libs/` inside the artifact.

## Local build (optional)

Requires Java 17 and Gradle 8.6+:

```sh
gradle build
```

## Current state

Only the Fabric entrypoint and build configuration are present. Entity AI, model, animation, sound design, spawn logic, configuration, and multiplayer behavior still need implementation and testing.
